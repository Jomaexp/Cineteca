<footer>
    <div class="contenedor_footer">
        <div class="derechos">
            <img width="20" heigth="20" src="../assets/iconos/copyright.svg" 
                alt="logo copyright" class="nav_img"></img>
            <p class="nav_derechos">2023 Algunos derechos reservados</p>  
        </div>
        <div class="contacto">
            <a href="../index.php/contacto">Contacte con nostros</a>
        </div>
        <div id="redes">
            <a href="https://twitter.com/?lang=es" target="_blank"><img  height="35" src="../assets/redes/twitter.png"></img></a>
            <a href="https://www.instagram.com/" target="_blank"><img height="35" src="../assets/redes/instagram.png"></img></a>
            <a href="https://es.linkedin.com/" target="_blank"><img height="35" src="../assets/redes/linkedin.png"></img></a>
        </div>
    </div>
</footer>
</body>
</html>