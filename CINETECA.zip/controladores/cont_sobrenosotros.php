<?php
    /**
     * Esta función va a mostrar directamente la vista "vista_sobrenosotros".
     */
    function cont_sobrenosotros(){

    require_once "vistas/vista_sobrenosotros.html";
}?>